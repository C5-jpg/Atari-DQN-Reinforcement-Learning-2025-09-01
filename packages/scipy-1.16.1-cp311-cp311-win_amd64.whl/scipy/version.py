
"""
Module to expose more detailed version info for the installed `scipy`
"""
version = "1.16.1"
full_version = version
short_version = version.split('.dev')[0]
git_revision = "0cf8e9541b1a2457992bf4ec2c0c669da373e497"
release = 'dev' not in version and '+' not in version

if not release:
    version = full_version
